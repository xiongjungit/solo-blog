title: Solo 用户指南
date: '2019-12-13 10:34:34'
updated: '2019-12-13 10:34:34'
tags: [Solo]
permalink: /articles/2019/12/13/1576204474231.html
---
# 💡 简介

[Solo](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2F88250%2Fsolo) 是一款小而美的开源博客系统，专为程序员设计。

Solo 有着非常活跃的[社区](https://hacpai.com)，可将文章作为帖子推送到社区，来自社区的回帖将作为博客评论进行联动。

> 这是一种全新的网络社区体验，让热爱记录和分享的你不再感到孤单！
> 具体细节请浏览 [B3log 构思](https://hacpai.com/article/1546941897596)

# 🗃 案例

[https://github.com/88250/solo]( https://github.com/88250/solo )  

# ✨ 功能

- Markdown / Emoji
- [标签聚合分类](https://hacpai.com/article/1558320086126)
- 自定义导航链接
- 随机文章 / 相关文章 / 置顶 / 更新提醒
- 自定义文章永久链接 / 签名档
- 配置站点 SEO 参数 / 公告 / 页脚
- 代码高亮 / 数学公式 / 流程图 / 五线谱
- [多皮肤，多端适配](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2F88250%2Fsolo-skins) / [社区皮肤](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2F88250%2Fsolo-third-skins)
- 多语言 / 国际化
- 友情链接管理
- 多用户写作，团队博客
- [Hexo / Jekyll / Markdown 导入](https://hacpai.com/article/1498490209748)
- SQL / JSON / Markdown 导出
- Atom / RSS / Sitemap
- CDN 静态资源分离
- [自动同步 GitHub 仓库](https://hacpai.com/article/1557238327458)
- [内置 HTTPS+CDN 文件存储](https://hacpai.com/article/1559928188793)

# 🎨 界面

## 开始使用

![start](https://user-images.githubusercontent.com/970828/61179568-96819e80-a637-11e9-8f73-5188d99ba454.png)

## 后台首页

![console](https://user-images.githubusercontent.com/970828/56886176-f210a700-6aa0-11e9-894f-75eda5cf3317.png)

## 编辑文章

![post](https://user-images.githubusercontent.com/970828/56886177-f2a93d80-6aa0-11e9-8a87-14731bdf59e7.png)

## 选择皮肤

![skins](https://user-images.githubusercontent.com/970828/61179517-afd61b00-a636-11e9-87d5-ddea6d6a0fc9.png)

## 前台界面

![Bubble](https://user-images.githubusercontent.com/970828/61182950-2ee64600-a66d-11e9-80d6-676ead6933d9.png)

![Casper](https://user-images.githubusercontent.com/970828/61182781-d6ae4480-a66a-11e9-84b3-8db55039caa0.png)

![pinghsu](https://user-images.githubusercontent.com/970828/61182902-86d07d00-a66c-11e9-980a-e75fc6624f98.png)

![Jane](https://user-images.githubusercontent.com/970828/61182948-25f57480-a66d-11e9-9e33-ded3b7ca87f2.png)

![nijigen](https://user-images.githubusercontent.com/970828/61182986-e67b5800-a66d-11e9-8dae-7cd94cc16e83.png)

![timeline](https://user-images.githubusercontent.com/970828/61183026-699cae00-a66e-11e9-9bba-ffff2a264a5d.png)

# 🍱 皮肤

目前内置的皮肤如下，可点击进行预览：

- [Bubble](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3DBubble)
- [Casper](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3DCasper)
- [Pinghsu](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3DPinghsu)
- [Jane](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3DJane)
- [nijigen](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3Dnijigen)
- [Medium](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3DMedium)
- [9IPHP](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3D9IPHP)
- [Andrea](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3DAndrea)
- [Bruce](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3DBruce)
- [Community](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3DCommunity)
- [favourite](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3Dfavourite)
- [Finding](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3DFinding)
- [i-nove](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3Di-nove)
- [metro-hot](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3Dmetro-hot)
- [NeoEase](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3DNeoEase)
- [next](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3Dnext)
- [owmx-3.0](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3Dowmx-3.0)
- [timeline](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3Dtimeline)
- [tree-house](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3Dtree-house)
- [yilia](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2F%3Fskin%3Dyilia)

欢迎在[该 issue](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2F88250%2Fsolo%2Fissues%2F12449) 下推荐好看的皮肤，我们会尽量进行制作。

# 🛠️ 安装

## 本地试用

[下载](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2F88250%2Fsolo%2Freleases)最新的 Solo 包解压，进入解压目录执行：

- Windows: `java -cp "lib/*;." org.b3log.solo.Server`
- Unix-like：`java -cp "lib/*:." org.b3log.solo.Server`

如果你有 Java 开发环境，可参考[这里](https://hacpai.com/article/1493822943172)通过源码构建运行。

**请注意**：我们不建议通过 zip 发布包或者源码构建部署，因为这样的部署方式在将来有新版本发布时升级会比较麻烦。
 这两种方式请仅用于本地试用，线上生产环境建议通过 Docker 部署。

## Docker 部署（推荐方案）

## 获取最新镜像

```shell
docker pull b3log/solo
```

## 启动容器

- 使用 MySQL

  先手动建库（库名 `solo`，字符集使用 `utf8mb4`，排序规则 `utf8mb4_general_ci`），然后启动容器：

  ```shell
  docker run --detach --name solo --network=host \
      --env RUNTIME_DB="MYSQL" \
      --env JDBC_USERNAME="root" \
      --env JDBC_PASSWORD="123456" \
      --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
      --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true" \
  b3log/solo --listen_port=8080 --server_scheme=http --server_host=localhost --server_port=
  ```

  为了简单，使用了主机网络模式来连接主机上的 MySQL。

- 使用 H2 Database

  ```shell
  docker run --detach --name solo --volume ~/solo_h2/:/opt/solo/h2/ --publish 8080:8080 \
      --env RUNTIME_DB="H2" \
      --env JDBC_USERNAME="root" \
      --env JDBC_PASSWORD="123456" \
      --env JDBC_DRIVER="org.h2.Driver" \
      --env JDBC_URL="jdbc:h2:/opt/solo/h2/db;MODE=MYSQL" \
  b3log/solo --listen_port=8080 --server_scheme=http --server_host=localhost --server_port=
  ```

启动参数说明：

- `--listen_port`：进程监听端口
- `--server_scheme`：最终访问协议，如果反代服务启用了 HTTPS 这里也需要改为 `https`
- `--server_host`：最终访问域名或公网 IP，不要带端口
- `--server_port`：最终访问端口，使用浏览器默认的 80 或者 443 的话值留空即可

完整启动参数的说明可以使用 `-h` 来查看。

## 日志配置

默认通过 log4j 将日志打印到标准输出流，可以通过 `docker logs solo` 进行查看。如果需要覆盖 log4j 配置，可通过挂载文件实现：

```shell
--volume ~/log4j.properties:/opt/solo/WEB-INF/classes/log4j.properties
```

## 皮肤配置

如果要使用其他皮肤，可以挂载目录 skins（里面需要包含所需使用的所有皮肤）：

--volume ~/skins/:/opt/solo/skins/

## 版本升级

1. 拉取最新镜像
2. 重启容器

可参考[这里](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2F88250%2Fsolo%2Fblob%2Fmaster%2Fscripts%2Fdocker-restart.sh)编写一个重启脚本，并通过 crontab 每日凌晨运行来实现自动更新。

## Docker Compose

请参考[这里](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2Fliumapp%2Fsolo-in-docker)，感谢 [@](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2Fliumapp)[liumapp](https://hacpai.com/member/liumapp) 提供。

## ARM/树莓派镜像

```shell
docker pull clinan/solo
```

## NGINX 反代

```fallback
upstream backend {
    server localhost:8080; # Solo 监听端口
}

server {
    listen       80;
    server_name  88250.b3log.org; # 博客域名

    access_log off;

    location / {
        proxy_pass http://backend$request_uri;
        proxy_set_header  Host $host:$server_port;
        proxy_set_header  X-Real-IP  $remote_addr;
        client_max_body_size  10m;
    }
}
```

感谢 [@](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2FClinan)[Clinan](https://hacpai.com/member/Clinan) 提供。

# 📜 文档

- [《提问的智慧》精读注解版](https://hacpai.com/article/1536377163156)
- [从零开始安装 Solo 博客](https://hacpai.com/article/1565021959471)（感谢 [@JInjianh](https://hacpai.com/forward?goto=https%3A%2F%2Fwww.jinjianh.com) 分享）
- [用户指南](https://hacpai.com/article/1492881378588)
- Solo 从设计到实现
  - [项目简介](https://hacpai.com/article/1537691255769)
  - [搭建开发环境](https://hacpai.com/article/1537694179006)
  - [架构理念和约定](https://hacpai.com/article/1537695161321)
  - [表结构](https://hacpai.com/article/1537694566175)
  - 功能实现
    - [源码包结构介绍](https://hacpai.com/article/1538711714296)
    - [登录验证 GitHub OAuth](https://hacpai.com/article/1554262218912)
    - [登录状态和会话](https://hacpai.com/article/1538708370634)
    - [发布文章](https://hacpai.com/article/1538893576597)
    - [自定义链接路由](https://hacpai.com/article/1543582332567)
    - [标签聚合分类](https://hacpai.com/article/1558320086126)
    - [发布评论](https://hacpai.com/article/1543642913006)
    - [Markdown 渲染](https://hacpai.com/article/1544880962218)
    - [导入 Markdown 文章](https://hacpai.com/article/1547643961141)
    - 皮肤切换
    - [自动同步 GitHub 仓库](https://hacpai.com/article/1557238327458)
    - [内置 HTTPS + CDN 文件存储](https://hacpai.com/article/1559928188793)
    - [跨版本升级](https://hacpai.com/article/1560169064267)
  - [安全相关](https://hacpai.com/article/1538896576775)
  - [错误处理](https://hacpai.com/article/1538901266090)
  - 性能相关     
    - 数据库设计
    - 查询 SQL
    - MySQL 调优
    - 程序缓存
    - Docker 镜像优化
  - 运维相关     
    - 开发、生产环境
    - NGINX 反代
    - 动静分离
    - 更好的 Markdown
    - 数据备份和迁移
    - 启用 HTTPS
    - 通过 Docker 部署实现自动升级
  - 后记     
    - 轮子理论
    - 关于开源
    - 现实和理想
    - 博客的未来
- [皮肤开发指南](https://hacpai.com/article/1493814851007)
- [插件开发](https://hacpai.com/forward?goto=https%3A%2F%2Fdocs.google.com%2Fdocument%2Fpub%3Fid%3D15H7Q3EBo-44v61Xp_epiYY7vK_gPJLkQaT7T1gkE64w%26pli%3D1)

# 🏘️ 社区

- [讨论区](https://hacpai.com/tag/solo)
- [报告问题](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2F88250%2Fsolo%2Fissues%2Fnew%2Fchoose)

# 📄 授权

Solo 使用 [GNU Affero General Public License, Version 3](https://hacpai.com/forward?goto=https%3A%2F%2Fwww.gnu.org%2Flicenses%2Fagpl-3.0.txt) 开源协议。

# 🙏 鸣谢

- [jQuery](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2Fjquery%2Fjquery)：前端 JavaScript 工具库
- [Vditor](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2F88250%2Fvditor)： 浏览器端的 Markdown 编辑器
- [Highlight.js](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2Fisagalaev%2Fhighlight.js)：前端代码高亮库
- [pjax](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2Fdefunkt%2Fjquery-pjax)：pushState + AJAX = pjax
- [jsoup](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2Fjhy%2Fjsoup)：Java HTML 解析器
- [flexmark](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2Fvsch%2Fflexmark-java)：Java Markdown 处理库
- [Apache Commons](https://hacpai.com/forward?goto=http%3A%2F%2Fcommons.apache.org)：Java 工具库集
- [Latke](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2F88250%2Flatke)：以 JSON 为主的 Java Web 框架

------

# 初始化后

初始化成功后请务必查看自动发布的第一篇文章，里面有一些**必要的操作**，请务必完成。然后请到管理后台 -> 工具 -> 偏好设定中进行一下博客的细节配置。

## 信息配置

- 博客基本信息：标题、子标题、SEO 信息
- HTML head：可以配置脚本，比如百度统计
- 公告：可以使用 HTML 和脚本进行配置
- 页脚：主要用来放备案信息，也可以使用 HTML 和脚本进行配置

## 签名档

最多可以配置 3 个签名档，发布文章的时候选择一个使用，可以使用 HTML 和脚本进行配置。

## 参数设置

下面是一些比较有特色或重要的参数：

- 列表显示方式：仅标题/标题 + 摘要/标题 + 正文
- 各种分页参数
- 文章更新提示：启用后一旦某篇文章更新过，则会在文章标题处显示“有更新”的提示，并且排序靠前
- 允许同步 GitHub 仓库：将文章数据自动导出到 GitHub 仓库，用于展示和备份

# 导入 Markdown

请参考 [Solo 支持 Hexo/Jekyll 数据导入](https://hacpai.com/article/1498490209748)。

# 备份

安全第一，血泪的教训 😢

- H2：备份用户 home 目录下的 solo_h2 文件夹
- MySQL：使用 MySQL 相关备份工具，或者到博客后台工具-> 其他中进行 SQL 导出

# 其他一些特性

## 多用户

可以几个用户同时使用一个博客发布文章，主要用在团队博客这个场景。权限方面做了简单隔离，非管理员用户可以看到其他用户的博文/评论列表，但是不能进行操作。

## RSS/Atom/Sitemap

提供两种订阅供稿：Atom 1.0、RSS 2.0：

- Atom: /rss.xml
- RSS: /atom.xml

不要用浏览器直接打开，请通过阅读器查看。另外，Solo 也能生成全站文章的 sitemap.xml。

## 前台皮肤切换

通过 URL 带参（比如 `http://88250.b3log.org/?skin=Finding`）来确定渲染使用的皮肤。

使用场景举例：

- 在不安装 Solo 的情况下可以方便预览各个皮肤（在 Demo 上）
- 方便二次开发时集成切换皮肤
- 博主可以让访客体验到不同的效果，比如：[这个](https://hacpai.com/forward?goto=http%3A%2F%2F88250.b3log.org%2F%3Fskin%3DFinding)皮肤好看？还是[这个](https://hacpai.com/forward?goto=http%3A%2F%2F88250.b3log.org%2F%3Fskin%3D9IPHP)好看？

1. 只有在首页（`/`）会取参数`skin=xxx`
2. 如果带有就记录到 Cookie 里面，如果带有`skin=default`或皮肤不存在则清空 Cookie
3. 如果要切换成后台默认的皮肤，在首页带参`skin=default`

## 站外相关文章

“站外相关文章”指的是其他人使用 Solo 发布的文章，该文章含有与你的文章相同的标签。该功能主要是为了加强各个 Solo 博客之间的互动性，让博客访问者可以更有效地访问到相关的内容。

这是 [B3log 构思](https://hacpai.com/b3log)的一部分实现，请大家积极参与进来 🙏

## 自动同步 GitHub 仓库

自动同步仓库包含了两个功能：

1. 每 24 小时定时拉取用户 GitHub 账号下的公有仓库，然后生成一篇文章并在加入到导航中，实际效果请参看[这里](https://hacpai.com/forward?goto=https%3A%2F%2F88250.b3log.org%2Fmy-github-repos)
2. 每 24 小时定时导出用户的公开文章到用户的 GitHub 仓库（solo-blog），实际效果请参考[这里](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2F88250%2Fsolo-blog)

# FAQ

## 服务器内存太小？

可以考虑使用内嵌的 H2 数据库代替 MySQL。但建议还是进行内存升级，然后使用 Docker 和 MySQL 部署，这样不仅可以通过更新镜像进行平滑升级，还能使用 MySQL 相关工具更方便地进行数据库运维。

## 获取社区文件存储服务上传凭证异常？

请参考[这里](https://hacpai.com/article/1550393688505)进行配置。

## 如何引入自定义静态资源，比如 .mp3？

请通过 NGINX 反代静态资源实现。

## 如何获得更好的 Markdown 渲染效果？

Solo 默认是使用内建的 [flexmark](https://hacpai.com/forward?goto=https%3A%2F%2Fgithub.com%2Fvsch%2Fflexmark-java) 进行 md 渲染，可能对有的场景下的渲染效果不是很好。如果你想要获得更好的 md 渲染效果请参考[这里](https://hacpai.com/article/1569240189601)。

## 为什么在线访问计数一直都是 1？

在线访问计数是通过访问者 IP 去重的，每 10 分钟定时刷新一次。如果用了反向代理，请在代理配置部分加入客户端地址标头。比如 NGINX 需要加入如下配置：

```fallback
  proxy_set_header  X-Real-IP  $remote_addr;
```

## 如何插入广告展位？

可通过签名档、公告栏中插入 HTML、JS 代码来实现。

## Solo 会一直维护下去么？

Solo 的第一个版本发布于 `2010` 年，永不断更 😼

Solo 从第一版开始就支持平滑升级，从 v3.0.0 开始支持跨版本升级。在程序升级、数据兼容迁移方面我们做了很多工作。另外，Solo 还支持将数据导出成多种格式，所有的这些努力为的就是让大家能够免去后顾之忧，将精力更多放在创作和分享上。

当然，也欢迎大家一起来学习、折腾 Solo 程序本身，因为开源项目参与者越多，说明这个项目生命力越旺盛 ❤️

# 结语

如果你在使用 Solo 过程中碰到问题或者有需求要提，欢迎跟帖，我们会在第一时间回复。另外，如果你想对 Solo 进行定制开发，请参考 [Solo 从设计到实现](https://hacpai.com/article/1537690756242)。
