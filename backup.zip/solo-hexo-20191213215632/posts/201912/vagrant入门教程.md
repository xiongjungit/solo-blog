title: vagrant入门教程
date: '2019-12-13 10:37:50'
updated: '2019-12-13 10:37:50'
tags: [vagrant]
permalink: /articles/2019/12/13/1576204670538.html
---
# 初识vagrant(1)

## vagrant简介

vagrant源码采用ruby编写，主要功能是快速搭建和配置轻量级的、可重用的、可移植的开发环境，简单概括，vagrant是基于配置文件和命令行的虚拟机管理工具。
vagrant完成了对虚拟化技术在一定程度上的封装,vagrant的运行需要依赖某项具体的虚拟化技术，常见的VirtualBox、VMware、AWS、Docker等都已经可以通过vagrant的管理而工作。

## vagrant解决了哪些问题

### 1 .统一了开发环境和生成环境

考虑如下场景：
开发者经常会遇到开发完成后代码在本地运行正常，提交到测试服务器之后出现bug，这就是由于开发环境和生成环境不一致而引起的。

通过借助vagrant，在虚拟机里部署和生产环境一致的开发环境，开发者在开发过程中代码相当于运行在生产环境上，因此解决了开发环境不同所导致的问题。

### 2 .快速搭建统一的开发环境

考虑如下场景：
搭建一个开发环境，需要完成操作系统(Windows、Mac OS X、Linux)的安装、软件的安装，配置操作系统和代码运行环境等等，如果团队成员都花费大量的时间在配置开发环境上，并且面临着开发环境不一致影响代码执行结果的风险，这将会严重影响开发效率。

vagrant很好的解决了上述场景遇到的问题，vagrant提供了统一的安装程序配置环境。

- 使用统一的配置文件(Vagrantfile)实现对服务器的统一配置
- 使用共享文件夹(shared folder )将本机代码运行在虚拟机服务器上
- 使用软件配置脚本(Provisioning scripts)实现服务器上的运行环境的快速建立

# 安装vagrant(2)

## 前言

本文将介绍安装vagrant和VirtualBox，其他虚拟机的安装将略过。

常用下载地址：

- vagrant[官网下载地址](https://www.vagrantup.com/downloads.html)
- VirtualBox[官网下载地址](https://www.virtualbox.org/wiki/Downloads)

## windows下安装

windows下安装可能会遇到和系统主题dll文件冲突等问题，需要安装特定的版本才行(趟过很多坑了…)，因此分享我的vagrant和VirtualBox的windows软件包，在安装过程中先安装VirtualBox一路next即可，安装完成后安装vagrant，同样一路next。
安装过程中系统将自动将vagrant的可执行文件写入系统环境变量，安装完成后可以检查是否写入了环境变量，若没有，重启电脑即可。

windows用户在使用vagrant的时候需要使用vagrant ssh命令登陆虚拟机操作系统，推荐一款工具cmder，分享我的[cmder软件包](http://pan.baidu.com/s/1eSqedGI)。

## MAC下安装

MAC下安装和windows下类似，分享我的[mac软件包](http://pan.baidu.com/s/1bpjyA7t)

## LINUX下安装

linux下可以使用前言当中列出的下载地址去下载安装。

# 基本配置(3)

## 配置VirtualBox的镜像文件存放位置

vagrant和VirtualBox安装完成后，默认存放虚拟机镜像文件的位置在系统盘，建议存储在其他磁盘下，具体步骤如下：

1. 打开VirtualBox，打开管理-> 全局设置 （快捷键是 Ctrl-G ）

2. 选择 常规 里的 默认虚拟电脑位置(M)

3. 设置为非系统盘的位置

## 配置vagrant的镜像存储位置

vagrant对于虚拟机的管理分成两个部分：box和Machine，box是指初始的未部署的虚拟机镜像文件，这个文件相当于是虚拟机的一个模板，可以进行无限制次数的复制，Machine指处于可运行状态下的虚拟机，当使用vagrant添加box(vagrant add)时，对于windows用户，vagrant会默认将这些虚拟机模板镜像文件存放在c:\User\.Vagrant.d文件夹下，当使用vagrant添加的box文件较多时，这个目录将会变得非常大，建议转移到其他磁盘分区，具体步骤如下：

1. 将 c:\User\.vagrant.d目录移动到新的位置
2. 设置VAGRANT_HOME 环境变量指向新的位置

windows用户设置：

![这里写图片描述](https://img-blog.csdn.net/20160722164402049)

注：若在后续操作中发现设置未生效，尝试重启电脑让新加入的环境变量生效。

MAC用户设置：

```
export VAGRANT_HOME='新位置路径'
```

# 添加box到本地仓库(4)

## box简介

box实际上是vagrant克隆一台虚拟机的基础镜像。
vagrant开源社区提供了很多box的[下载地址](http://www.vagrantbox.es/)，使用国外的源添加box会遇到下载速度比较慢的情况，分享我下载的box文件，如下：

- [centos-6.5_chef_32.box](http://pan.baidu.com/s/1miplSDE)
- [centos-6.5_chef_64.box](http://pan.baidu.com/s/1o81Zb9C)
- [centos-7.0_chef.box](http://pan.baidu.com/s/1o7BSmoU)
- [ubuntu_trusty_32.box](http://pan.baidu.com/s/1i4BwyUD)
- [ubuntu_trusty_64.box](http://pan.baidu.com/s/1pLzVhnP)

## 添加box

在命令行下添加box命令格式：

```
vagrant box add 自定义你的box名称  box路径
```

添加box到本地仓库有三种方式：

### 1 . 使用http远程添加

```
vagrant box add my_first_box  https://github.com/tommy-muehle/puppet-vagrant-boxes/releases/download/1.1.0/centos-7.0-x86_64.box
```

### 2 . 使用本地box文件

```
vagrant box add my_first_box D:/centos-7.0-x86_64.box
```

### 3 .使用中央仓库名称

```
vagrant box add my_first_box hashicorp/precise64
```

本文将演示使用第二种本地添加box文件的方式

![这里写图片描述](https://img-blog.csdn.net/20160722181757302)

接上篇文章[vagrant入门教程–基本配置(3) ](http://blog.csdn.net/zsl10/article/details/51996436)，添加box完成后，vagrant
将存储初始box：

![这里写图片描述](https://img-blog.csdn.net/20160725112837397)

## 查看已添加的box

查看已添加的box，使用命令

```
vagrant box list
```

![这里写图片描述](https://img-blog.csdn.net/20160725113017372)

## 删除box

删除box使用如下命令：

```
vagrant box remove your_box_name
```

# 初始化虚拟机(5)

## 初始化虚拟机

使用vagrant初始化虚拟机类似上篇文章vagrant入门教程–添加box到本地仓库(4) ，同样有三种方式，命令格式如下：

```
vagrant init [box_name]
```

### 1 .使用http绝对地址远程初始化

```
vagrant init https://github.com/tommy-muehle/puppet-vagrant-boxes/releases/download/1.1.0/centos-7.0-x86_64.box

```

如果之前没有执行添加box 指令( vagrant box add)，直接初始化虚拟机时，会先添加box，完成后再执行初始化操作。因此，使用这种方式初始化虚拟机可以略过上一步添加box操作。

### 2 .使用本地box

```
vagrant init my_first_box

```

### 3 .使用Vagrantfile文件

通过虚拟机配置文件Vagrantfile初始化虚拟机，即在配置文件中指定box名称和地址，同样使用这种方式也可以略过上一步添加box操作。

```
git clone https://github.com/coreos/coreos-vagrant.git

```

## 演示

使用第二种方式初始化虚拟机如下：

![这里写图片描述](https://img-blog.csdn.net/20160725150806580)

此时将在目录下生成vagrant的配置文件Vagrantfile，如下：

![这里写图片描述](https://img-blog.csdn.net/20160725151011821)

# 管理虚拟机(6)

## 启动虚拟机

接上一篇文章[vagrant入门教程–初始化虚拟机(5)](http://blog.csdn.net/zsl10/article/details/52023989)初始化虚拟机后的所在目录，执行

```
vagrant up [vm_name]

```

注：

1 .在vmware上：

```
 vagrant up  –provider=vmware_fusion [vm_name]

```

２．在AWS上：

```
 vagrant up  –provider=aws [vm_name]

```

３ .[vm_name]为虚拟机的名字，指定运行某个虚拟机

启动虚拟机，如下：

![这里写图片描述](https://img-blog.csdn.net/20160725155444966)

打开VirtualBox客户端，可以看到虚拟机已经正常启动：

![这里写图片描述](https://img-blog.csdn.net/20160725160134466)

所在目录将生成.vagrant文件夹，如下：

![这里写图片描述](https://img-blog.csdn.net/20160725155733665)

生成的虚拟机镜像文件，如下：

![这里写图片描述](https://img-blog.csdn.net/20160725155958386)


注：启动虚拟机时，虚拟机默认不提供图形界面。

## 查看虚拟机状态

使用命令：

```
vagrant status

```

![这里写图片描述](https://img-blog.csdn.net/20160727111826844)

## 登录虚拟机

可以使用ssh登陆虚拟机，使用如下命令：

```
vagrant ssh [vm_name]

```

通常情况下，vagrant在创建虚拟机的时候，内置了1个用户：

```
username:vagrant 
password:vagrant 

```

注：

1 .若要切换root用户，通常情况下root用户密码默认为vagrant
2 .windows用户若要使用ssh登陆，建议使用工具cmder

演示登陆如下：

![这里写图片描述](https://img-blog.csdn.net/20160725161249764)

## 停止虚拟机

### 1 .虚拟机挂起

```
vagrant suspend [vm_name]

```

### 2 .虚拟机关机

```
vagrant halt [vm_name]

```

## 重启虚拟机

```
vagrant reload [vm_name]

```

## 查看已创建的所有虚拟机

```
vagrant global-status

```

演示：

![这里写图片描述](https://img-blog.csdn.net/20160727143052927)

## 销毁虚拟机

```
vagrant destory [vm_id]

```

接上一步的列表id，演示：

![这里写图片描述](https://img-blog.csdn.net/20160727143340318)

注：

1 . 虚拟机删除后，所有在虚拟机中做的改动都不再存在，慎用。　　

2 .执行销毁虚拟机命令后，box文件仍然是存在的，彻底解放硬盘空间可以执行`vagrant box remove your_box_name`删除box文件

# 管理虚拟机快照(7)

## 新建快照

使用命令：

```
vagrant snapshot save your_snapshot_name

```

如下：

![这里写图片描述](https://img-blog.csdn.net/20160725164530277)


## 查看快照

使用命令：

```
vagrant snapshot list

```

如下：

![这里写图片描述](https://img-blog.csdn.net/20160725164650381)

## 恢复快照

```
vagrant snapshot restore your_snapshot_name

```

## 删除快照

```
vagrant snapshot delete your_snapshot_name

```

# 共享文件夹配置(8)

## 前言

vagrant提供了将本机目录挂载到虚拟机目录下的功能，默认是将vagrant配置文件所在目录挂载到虚拟机/vagrant目录下。

## 配置

打开配置文件Vagrantfile，找到如下配置项：

```
config.vm.synced_folder

```

配置项如下：

```
config.vm.synced_folder   
   "your_folder"(必须)   //物理机目录，可以是绝对地址或相对地址，相对地址是指相对与vagrant配置文件所在目录
  ,"vm_folder(必须)"    // 挂载到虚拟机上的目录地址
  ,create(boolean)--可选     //默认为false，若配置为true，挂载到虚拟机上的目录若不存在则自动创建
  ,disabled(boolean):--可选   //默认为false，若为true,则禁用该项挂载
  ,owner(string):'www'--可选   //虚拟机系统下文件所有者(确保系统下有该用户，否则会报错)，默认为vagrant
  ,group(string):'www'--可选   //虚拟机系统下文件所有组( (确保系统下有该用户组，否则会报错)，默认为vagrant
  ,mount_options(array):["dmode=775","fmode=664"]--可选  dmode配置目录权限，fmode配置文件权限  //默认权限777
  ,type(string):--可选     //指定文件共享方式，例如：'nfs'，vagrant默认根据系统环境选择最佳的文件共享方式

```

我的配置如下：

```
config.vm.synced_folder
      "D:/www/code"
      , "/code"
      , owner:"www"
      , group:"www"
      ,create:true
      ,mount_options:["dmode=775","fmode=664"]

config.vm.synced_folder ".","/vagrant",disabled:true //禁用vagrant的默认共享目录

```

# 网络配置(9)

## 前言

vagrant提供了三种网络配置方式：端口转发(默认)、私有网络、公有网络，可以在配置文件Vagrantfile进行网络配置，推荐使用私有网络。

## 端口转发(forwarded ports)

### 1 .定义

端口转发指把宿主机的端口映射到虚拟机的某一个端口上，访问宿主机端口时，请求实际是被转发到虚拟机上指定端口的。
注：宿主机指运行虚拟机的物理机。

### 2 .优点

- 容易实现外网访问虚拟机

### 3 .缺点

- 如果端口较少需要映射很容易，但是端口比较多时，就比较麻烦，例如：MySQL，redis，nginx等服务。
- 不支持在宿主机使用小于1024的端口来转发，例如：不能使用SSL的443端口来进行https连接。

### 4 .配置

在配置文件Vagrantfile下做如下编辑

```
Vagrant.configure("2") do |config|
  config.vm.network  
       "forwarded_port"(必须) //端口转发标识
       , guest(必须): //虚拟机端口
       , host(必须): //宿主机端口，值必须大于1024
       ,guest_ip(可选): //虚拟机端口绑定虚拟机ip地址
       ,host_ip(可选): //虚拟机端口绑定宿主机ip
       ,protocol(可选)://指定通信协议，可以使用tcp/udp，默认tcp
       ,auto_correct(可选)://true/false，若配置为true，则每次开启虚拟机的时候自动检查是否存在端口冲突
end

```

注：若guest_ip和host_ip两项配置为空，则局域网下的所有设备都可以访问该虚拟机。

示例配置，如下：

```
Vagrant.configure("2") do |config|
  config.vm.network "forwarded_port", guest: 80, host: 8080,
    auto_correct: true
end

```

访问宿主计算机8080端口的请求都转发到虚拟机的80端口上进行处理。

## 私有网络(private networks)

### 1 .定义

私有网络是指只有宿主机可以访问虚拟机，如果多个虚拟机设定在同一个网段也可以互相访问。

### 2 .优点

- 安全，只有自己可以访问

### 3 .缺点

- 团队成员不能访问你的虚拟机

### 4 .配置

配置如下：

```
config.vm.network 
                 "private_network"//必须 ，私有网络标识
                 , ip: "192.168.33.10"

```

注：私有ip可以自行指定

## 公有网络(public networks)

### 1 .定义

公有网络是指设置虚拟机和宿主机有相同的网络配置。

### 2 .优点

- 方便团队协作，别人可以访问你的虚拟机

### 3 .缺点

只有在有网络的情况下才能访问虚拟机

### 4 .配置

```
Vagrant.configure("2") do |config|
  config.vm.network 
   "public_network" //必须 公有网络标识
  ,ip(string):  //可选，配置静态ip
  ,bridge(string/array): "en1: Wi-Fi (AirPort)"//可选，设置桥接的网卡
end
```


