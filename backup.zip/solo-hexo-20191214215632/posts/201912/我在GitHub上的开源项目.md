title: 我在 GitHub 上的开源项目
date: '2019-12-14 21:46:31'
updated: '2019-12-14 21:46:31'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [SecurityManageFramwork-SeMF](https://github.com/xiongjungit/SecurityManageFramwork-SeMF) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`3`](https://github.com/xiongjungit/SecurityManageFramwork-SeMF/watchers "关注数")&nbsp;&nbsp;[⭐️`88`](https://github.com/xiongjungit/SecurityManageFramwork-SeMF/stargazers "收藏数")&nbsp;&nbsp;[🖖`47`](https://github.com/xiongjungit/SecurityManageFramwork-SeMF/network/members "分叉数")</span>

企业内网安全管理平台，包含资产管理，漏洞管理，账号管理，知识库管、安全扫描自动化功能模块，可用于企业内部的安全管理。 本平台旨在帮助安全人员少，业务线繁杂，周期巡检困难，自动化程度低的甲方，更好的实现企业内部的安全管理。



---

### 2. [websecuritymap](https://github.com/xiongjungit/websecuritymap) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiongjungit/websecuritymap/watchers "关注数")&nbsp;&nbsp;[⭐️`4`](https://github.com/xiongjungit/websecuritymap/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiongjungit/websecuritymap/network/members "分叉数")</span>

白帽子讲web安全思维导图



---

### 3. [bd_search](https://github.com/xiongjungit/bd_search) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/xiongjungit/bd_search/watchers "关注数")&nbsp;&nbsp;[⭐️`4`](https://github.com/xiongjungit/bd_search/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/xiongjungit/bd_search/network/members "分叉数")</span>

python+selenuim爬取百度搜索结果分别保存到文件和数据库



---

### 4. [docker-centos](https://github.com/xiongjungit/docker-centos) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiongjungit/docker-centos/watchers "关注数")&nbsp;&nbsp;[⭐️`4`](https://github.com/xiongjungit/docker-centos/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/xiongjungit/docker-centos/network/members "分叉数")</span>

自动构建阿里云源的CentOS 7的docker基础镜像Dockerfile



---

### 5. [mygitbook](https://github.com/xiongjungit/mygitbook) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiongjungit/mygitbook/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/xiongjungit/mygitbook/stargazers "收藏数")&nbsp;&nbsp;[🖖`4`](https://github.com/xiongjungit/mygitbook/network/members "分叉数")</span>

gitbook电子书



---

### 6. [docker-ghost](https://github.com/xiongjungit/docker-ghost) <kbd title="主要编程语言">Shell</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiongjungit/docker-ghost/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/xiongjungit/docker-ghost/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiongjungit/docker-ghost/network/members "分叉数")</span>

Ghost 是一套基于 Node.js 构建的开源博客平台



---

### 7. [docker-editormd](https://github.com/xiongjungit/docker-editormd) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiongjungit/docker-editormd/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/xiongjungit/docker-editormd/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/xiongjungit/docker-editormd/network/members "分叉数")</span>

editor.md的docker镜像创建文件



---

### 8. [docker-octopress](https://github.com/xiongjungit/docker-octopress) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiongjungit/docker-octopress/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/xiongjungit/docker-octopress/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/xiongjungit/docker-octopress/network/members "分叉数")</span>

Octopress是一个基于Jekyll的静态博客站点生成系统，它很大程度上简化了用Jekyll搭建博客的过程。



---

### 9. [docker-gitblog](https://github.com/xiongjungit/docker-gitblog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`2`](https://github.com/xiongjungit/docker-gitblog/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/xiongjungit/docker-gitblog/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/xiongjungit/docker-gitblog/network/members "分叉数")</span>

Gitblog是一个简单，易用，高效的Markdown博客系统



---

### 10. [docker-ubuntu-ssh](https://github.com/xiongjungit/docker-ubuntu-ssh) <kbd title="主要编程语言">Shell</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/xiongjungit/docker-ubuntu-ssh/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/xiongjungit/docker-ubuntu-ssh/stargazers "收藏数")&nbsp;&nbsp;[🖖`2`](https://github.com/xiongjungit/docker-ubuntu-ssh/network/members "分叉数")</span>

ubuntu包含openssh的基础docker镜像

