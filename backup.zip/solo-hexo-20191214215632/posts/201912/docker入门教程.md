title: docker入门教程
date: '2019-12-13 10:17:24'
updated: '2019-12-13 10:18:15'
tags: [docker]
permalink: /articles/2019/12/13/1576203444057.html
---
# [Docker是什么](https://www.cnblogs.com/cjsblog/p/8341054.html)

Docker是世界上领先的软件集装箱化平台。它灵活、可移植、安全、节省成本。

Container是一个标准化的软件单元。

## About Containers

**Package software into standardized units for development, shipment and deployment**

一个容器镜像是一个轻量级的、独立的、可以执行的软件包，其中包含运行这个软件所必须的：代码、运行时环境、系统工具、系统库、设置等待。无论是这个应用是Linux环境下的还是Windows环境下的都可以，无论什么环境下，集装箱化的软件运行起来总是一样的。容器将软件和它周围的其它软件隔离开，在相同的基础设施上运行不同的软件，容器可以帮助减少冲突。

### 轻量级

Docker容器运行在单个机器上，它们共享这台机器的操作系统内核，它们能够快速启动，并且占用很少的计算机和内存资源。

### 标准

Docker容器基于开发的标准，并且支持各大主流的Linux发行版本、Windows版本。

### 安全

Docker容器之间是隔离的

## Containers And VMs

Container虚拟化的是操作系统，而VM虚拟化的是硬件。

容器是app层面的抽象，它把代码和它们的依赖一起打包。一台机器上可以运行多个容器，并且它们共享操作系统内核，而且在不同的用户空间被隔离。容器比虚拟机花费更少的空间（容器镜像通常只有几十MBs），而且启动非常快。

虚拟机是物理硬件层面的抽象，它的目标是把一个服务器转成多个服务器。一台物理机上可以运行多个虚拟机。每个虚拟机都包含一个操作系统的完全复制，已经一个或多个应用和它们所需的库。通常一个虚拟机几十GBs。虚拟机启动比较慢。

 

一句话总结：Docker是平台，Container是这个平台中的一个标准的单元。

 

补充一句，我觉得有点像新浪SAE中的容器。

 

参考  https://www.docker.com/what-container

 

![img](https://images2017.cnblogs.com/blog/874963/201801/874963-20180124122152944-899660909.png)



# [Docker 快速开始](https://www.cnblogs.com/cjsblog/p/10764105.html)

## 1. 概念

对于开发人员和系统管理员来说，Docker是一个使用容器**开发**、**部署**和**运行**应用程序的平台。使用Linux容器部署应用程序称为容器化。容器并不新鲜，但是将它们用于轻松部署应用程序却很新鲜。

容器化越来越受欢迎，是因为容器有以下特点：

- 灵活性：即使是最复杂的应用程序也可以被容器化
- 轻量级：容器利用并共享主机内核
- 可互换的：你可以实时部署更新和升级
- 可移植性：你可以在本地构建、部署到云，并在任何地方运行
- 可伸缩：你可以增加并自动分发容器副本
- 可叠加：你可以垂直地、动态地叠加服务

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190425095224313-707531530.png)

## 2. 镜像与容器

**image（译：镜像）**

一个镜像是一个可执行包，它包含运行应用程序所需的所有内容，包括代码、运行时环境、库、环境变量、配置文件。通过运行镜像类启动一个容器。

**container（译：集装箱；容器）**

容器是镜像的运行时实例。你可以使用docker ps命令看到正在运行的容器列表，就像在Linux中一样。

（PS：镜像与容器的关系，就好比是类与对象的关系一样。镜像是静态的，当镜像运行的时候它就是一个容器）

## 3. 容器与虚拟机

容器在Linux本地运行，并与其他容器共享主机的内核。它以独立的进程运行，不占用比任何其他可执行程序更多的内存，使其轻量级。相反，虚拟机（VM）运行一个成熟的“客户”操作系统，通过管理程序对主机资源进行虚拟访问。一般来说，VMs提供的环境比大多数应用程序所需的资源要多。

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190425101346223-1429668069.png)  ![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190425101408513-1664148418.png)

## 4. 安装Docker

就像我们要使用mysql命令之前必须先安装mysql服务一样。Docker作为服务运行，我们也必须先安装它，这里我们安装Mac版。

https://hub.docker.com/search/?type=edition&offering=community

Docker有社区版和企业版，由于笔者的机器限制，此处只能选择安装 “Docker Desktop for Mac”

https://hub.docker.com/editions/community/docker-ce-desktop-mac

注册账号，安装，安装成功并登录后就可以使用了

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190424182203066-1215106221.png)

接下来，测试一下刚才安装的Docker

```
docker version
docker run hello-world
docker image ls
docker container ls --all
docker container --help
```

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190424182550711-864294948.png)

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190424182558995-1653044581.png)



```
localhost:~ chengjiansheng$ docker image ls                 
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
hello-world         latest              fce289e99eb9        3 months ago        1.84kB
localhost:~ chengjiansheng$ docker container ls --all
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS                      PORTS               NAMES
a9c306fa88b2        hello-world         "/hello"            19 minutes ago      Exited (0) 19 minutes ago                       elegant_heisenberg
```



## 5. 备忘单

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190424182643864-1643978555.png)

## 6. 文档

https://docs.docker.com/get-started/



# [Docker 容器](https://www.cnblogs.com/cjsblog/p/10767865.html)

## 1. 容器

在过去，如果要开始编写Python应用程序，首先要做的就是在机器上安装Python运行时环境。但是，这就造成了这样一种情况：你的机器上的环境需要完美，以便你的应用程序能够按预期运行，而且还需要与你的生产环境相匹配。

使用Docker，你只需要获取一个可移植的Python运行时作为镜像，不需要安装。然后，当你构建应用程序时就会在代码旁边包含基本的Python镜像，确保应用程序、它的依赖项和运行时一起运行。

这些可移植的镜像被一些称之为“Dockerfile”来定义。

## 2. 用Dockerfile定义一个容器

Dockerfile

示例：

在你的本地机器上创建一个空目录，进入该目录，然后在此目录下创建一个名字叫Dockerfile的文件，将下列内容复制粘贴到文件中，保存。

```
# Use an official Python runtime as a parent image
FROM python:2.7-slim

# Set the working directory to /app
WORKDIR /app

# Copy the current directory contents into the container at /app
COPY . /app

# Install any needed packages specified in requirements.txt
RUN pip install --trusted-host pypi.python.org -r requirements.txt

# Make port 80 available to the world outside this container
EXPOSE 80

# Define environment variable
ENV NAME World

# Run app.py when the container launches
CMD ["python", "app.py"]
```

可以看到，Dockerfile文件需要引用app.py和requirements.txt文件，于是，在与Dockerfile同级的目录下创建这两个文件

requirements.txt

```
Flask
Redis
```

app.py

```
from flask import Flask
from redis import Redis, RedisError
import os
import socket

# Connect to Redis
redis = Redis(host="redis", db=0, socket_connect_timeout=2, socket_timeout=2)

app = Flask(__name__)

@app.route("/")
def hello():
    try:
        visits = redis.incr("counter")
    except RedisError:
        visits = "<i>cannot connect to Redis, counter disabled</i>"

    html = "<h3>Hello {name}!</h3>" \
           "<b>Hostname:</b> {hostname}<br/>" \
           "<b>Visits:</b> {visits}"
    return html.format(name=os.getenv("NAME", "world"), hostname=socket.gethostname(), visits=visits)

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=80)
```

构建App

```
$ ls
Dockerfile		app.py			requirements.txt
docker build --tag=friendlyhello .
$ docker image ls

REPOSITORY            TAG                 IMAGE ID
friendlyhello         latest              326387cea398
```

注意：tag默认是latest，当然你可以手动指定，比如：--tag=friendlyhello:v0.0.1

## 3. 运行App

运行app，将本地4000端口映射到容器对外公布的80端口

```
docker run -p 4000:80 friendlyhello
```

## 4. 共享你的镜像

为了能够在任何地方都运行，我们需要将我们的镜像上传到注册中心。注册中心是仓库的集合，而仓库是镜像的集合。这很像GitHub仓库或者Maven仓库。一个账号可以在注册中心中创建许多个仓库。

用Docker ID登录

```
$ docker login
```

## 5. 给镜像打标签

将本地镜像关联到注册中心的某个仓库，格式是这样的： username/repository:tag

其中，tag是可选的，但是推荐加上tag。当你关联到仓库后，注册中心会给这个镜像分配一个版本号

给镜像打Tag的格式如下：

```
docker tag image username/repository:tag

```

例如，我们给我们刚才的friendlyhello打一个tag

```
docker tag friendlyhello gordon/get-started:part2

```

## 6. 发布镜像

```
docker push username/repository:tag

```

（PS：这个过程很像git在本地打标签并推送到远程仓库）

```
1 git tag v1.0
2 git push origin v1.0 

```

推送成功以后，我们就可以在注册中心看到了

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190426144745900-2052043986.png) 

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190425231306301-141683147.gif)

## 7. 备忘单

```
docker build -t friendlyhello .  # Create image using this directory's Dockerfile
docker run -p 4000:80 friendlyhello  # Run "friendlyhello" mapping port 4000 to 80
docker run -d -p 4000:80 friendlyhello         # Same thing, but in detached mode
docker container ls                                # List all running containers
docker container ls -a             # List all containers, even those not running
docker container stop <hash>           # Gracefully stop the specified container
docker container kill <hash>         # Force shutdown of the specified container
docker container rm <hash>        # Remove specified container from this machine
docker container rm $(docker container ls -a -q)         # Remove all containers
docker image ls -a                             # List all images on this machine
docker image rm <image id>            # Remove specified image from this machine
docker image rm $(docker image ls -a -q)   # Remove all images from this machine
docker login             # Log in this CLI session using your Docker credentials
docker tag <image> username/repository:tag  # Tag <image> for upload to registry
docker push username/repository:tag            # Upload tagged image to registry
docker run username/repository:tag                   # Run image from a registry

```

 

# [Docker 服务](https://www.cnblogs.com/cjsblog/p/10775727.html)


 ## 1. Docker服务

作为一名后端攻城狮，对“服务”这个概念一定不陌生。比如，我们做一个会员系统，它可能会需要数据库、缓存、消息队列，这些都是中间件服务，除此以外可能还需要依赖其它的Dubbo服务。

在Docker中，服务就是用于生产环境的容器（“containers in production”）。我们可以这样来理解这句话，当我们运行某个镜像时，其实就产生了一个镜像实例，这个实例我们把它叫做容器，接下来我们对它做个升级，比如一些配置负载均衡，配置域名解析映射等，最终它以web服务的形式运行，那么这个升级版的容器就是Docker服务。可以设想一下开发一个Java应用程序是怎样的过程，首先建一个工程，然后编写代码，打成jar包，在内网运行，配置nginx，配置告警及监控，经过这一系列操作后，客户端才能通过公网访问到这个服务。（PS：类比Java的话，镜像就是类，容器就是对象，服务就是一个成型的APP产品，或者叫服务）

一个服务只运行一个映像，但是它将镜像运行的方式进行了编码，比如应该使用什么端口，应该运行多少个容器副本，以便服务具有所需的能力，等等。可以通过改变运行该软件的容器实例的数量来对服务进行扩容，从而为流程中的服务分配更多的计算资源。

幸运的是，使用Docker平台很容易定义、运行和扩容服务。只需要写一个docker-compose.yml文件即可。

## 2. 第一个docker-compose.yml文件

创建一个文件，文件命名为docker-compose.yml，将下列内容粘贴到文件中，保存

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190426174240370-1248384641.png)

一个docker-compose.yml文件是一个YAML文件，它定义了Docker容器在生产环境中的行为。

这个docker-compose.yml文件告诉Docker要做以下事情：

- 从注册中心上pull（拉取）镜像
- 以web服务的形式运行该映像的5个实例，限制每个实例最多只能使用CPU单个内核时间的10%（也可以是“1.5”，表示每个实例只能使用1.5个内核）和50MB内存
- 如果一个容器失败，立即重启它
- 将主机上的4000端口映射到web的80端口
- 指示web容器通过叫webnet的负载均衡网络共享80端口
- 用默认设置定义webnet网络

## 3. 运行新的负载均衡的APP

首先，运行

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190426174459957-235660299.png)

接下来，给APP起个名字，比如叫getstartedlab

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190426174149707-51395665.png)

我们的单个服务堆栈在一台主机上运行了5个容器实例，让我们来看一看

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190426174725024-1428486121.png)

除了“docker service ls”，我们还可以通过“docker stack services”来查看

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190426174750334-670117291.png)

还可以通过修改docker-compose.yml来动态的扩展app，修改为后需要再执行一次

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190427120018537-1479988074.png)

完整的演示

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190427115400262-1875647811.gif)

## 4. 备忘单

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190427120151048-1852817042.png) 



# [Docker 集群](https://www.cnblogs.com/cjsblog/p/10778493.html)

## 1. 理解swarm

swarm（译：集群）

一个swarm是一组运行着Docker的机器，它们一起加入到一个集群。swarm中的机器既可以是物理机，也可以是虚拟机。在加入到一个swarm后，每台机器被称为一个节点。以前，我们执行docker命令由对应的机器去执行，而现在多台机器组成swarm后，命令由swarm manager去执行。

swarm manager 可以用多种策略来运行容器，比如“empties node”，用容器填充利用率最低的机器；或者“global”，它确保每台机器只获得指定容器的一个实例。

swarm manager 是在一个swarm中唯一能够执行你的命令的机器，或者授权其它机器以workers身份加入。Workers仅仅只是在提供生产能力，它没有权力告诉其他机器它能做什么和不能做什么。

到目前为止，你一直在本地机器上以single-host mode（单机模式）使用Docker。但是Docker也可以切换到swarm mode（群集模式），这就是启用群集的原因。启用群集模式将立即使当前机器成为swarm manager。从那时起，Docker将运行你所管理的swarm上执行的命令，而不仅仅是在当前机器上。

**小结&回顾：**

- swarm就是集群，是Docker集群，它是一组运行着Docker的机器组成的
- 组成Docker集群以后，集群中的每台机器被称之为一个node，其中有一台机器是这个集群的管理者，称之为manager，其余的称之为worker
- 在集群中，你的命令都是由manager去执行的，这与你当前在那台机器上输入的命令无关
- 与集群模式相对的是单机模式，之前我们一直是以单机模式使用Docker的
- 类比Redis机器的话，manager就相当于master，worker相当于slave

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190427134552700-1536307855.png)

## 2. 设置swarm

集群由多个节点组成，可以是物理节点，也可以是虚拟节点。

运行docker swarm init以启用群集模式，并且使当前的机器成为一个群集manager，然后在其它机器上运行docker swarm join，让它们作为worker加入到群集中。

## 3. 创建集群

首先，我们需要hypervisor来创建虚拟机。官方支持的是VirtualBox，因此首先要安装VirtualBox

https://www.virtualbox.org/wiki/Downloads

https://docs.docker.com/machine/drivers/

安装完以后，使用 docker-machine 命令来创建两个虚拟机

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428174642098-854958431.png)

现在我们就有了两个虚拟机，分别是myvm1和myvm2，接下来可以通过docker-machine ls 命令查看

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428174838754-346574281.png)

我们可能看到这样的输出

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428175120508-2090435032.png)

有了虚拟机以后，接下来初始化集群并添加节点

第一台启动的机器是集群中的manager，它可以执行管理命令，并且授权其它的机器以worker身份加入到该集群中。

第二台启动的机器是worker

通过 docker-machine ssh 命令，可以远程登录到刚才我们创建的虚拟机上，就像我们在Linux系统上使用ssh远程登录一样

也就是说，通过 docker-machine ssh 我们可以与远程虚拟机通讯

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428180450912-208393826.png)

还可以对虚拟机进行启动和停止操作

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428180248324-1440790235.png)

登录到虚拟机以后就可以像在本机上那样执行各种命令了，比如：

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428180759464-1221659771.png)

## 4. 部署应用到集群

前面我们也说过，只有集群中的manager才能执行命令，因此我们可以登录到myvm1上创建一个docker-compose.yml文件

当然最简单的是使用docker-machine scp命令从本地拷贝一个，比如：

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428181639545-1360045299.png)

语法格式如下：

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428181652315-464000900.png)

现在，myvm1上有了docker-compose.yml文件，

于是，我们就可以在myvm1上执行 docker stack deploy -c docker-compose.yml getstartedlab 命令

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428181905594-1867070299.png)

应用已经部署到集群了，接下来我们可以访问任意机器，简单起见就不用浏览器访问了，直接curl

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428182415364-247892397.png)

看下集群中是如何负载均衡的，默认策略是随机

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428182832652-885828447.png)

查看一下stack，确实启动了5个服务实例

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428183952010-414014836.png)

## 5. 完整演示

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428184214342-598609733.gif)

## 6. 备忘单

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190428185150263-1055150165.png)

## 7. 文档

https://docs.docker.com/get-started/part4/

https://docs.docker.com/machine/reference/create/

 

# [Docker 堆栈](https://www.cnblogs.com/cjsblog/p/10778661.html)

## 1. Stack

stack（译：堆叠，堆栈）是一组相互关联的服务，它们共享依赖关系，并且可以一起编排和伸缩。

在上一篇《[Docker 服务](https://www.cnblogs.com/cjsblog/p/10775727.html)》中我们知道可以通过创建一个docker-compose.yml文件，并使用docker stack deploy来部署stack。但那是运行在单机上的单个服务stack，在实际生产环境中是绝不会这样做的。因此，我们有必要掌握使多个服务彼此关联，并在多台机器上运行它们。

## 2. 添加一个新的服务并重新部署

（1）编辑docker-compose.yml

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190427142304889-178117941.png)

这里，我们添加了一个和web对等的新服务，名字叫visualizer。有两点需要注意：

- volums，它为Docker提供了对主机socket文件的可视化访问
- placement，确保该服务只在manager上运行，而不是在worker上

这是因为这个容器是由Docker创建的一个开源项目构建的，它在图中显示了运行在集群上的Docker服务

（2）更新docker-compose.yml并重新部署

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190429110019309-282732594.png)

（3）访问

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190429110111749-1358790672.png)

（4）在此基础上，再添加一个redis服务

为了和之前的配置区别开，这里我们新建一个文件docker-compose-with-redis.yml

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190429111614827-355240372.png)

在myvm1宿主目录下创建data目录

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190429112042626-141347784.png)

重新部署

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190429111830896-1426771357.png)

再访问manager的80端口，可以看到我们每访问一次，页面上的访问数量都会加1

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190429111907377-60898201.png) 

## 3. 完整演示

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190429111712730-814284923.gif)

## 4. 备忘单

![img](https://img2018.cnblogs.com/blog/874963/201904/874963-20190429112739887-109250892.png) 



# [Docker for Java Developers](https://www.cnblogs.com/cjsblog/p/10806814.html)

## 1. 基本概念

### 1.1. 主要组件

Docker有三个主要组件：

- 镜像是Docker的构建组件，而且是定义应用程序操作系统的只读模板
- 容器是Docker的运行组件，它是从镜像创建的。容器可以运行、启动、停止、移动和删除
- 镜像在注册中心中存储、共享和管理，并且是Docker的分发组件。Docker Store 是一个公开可用的注册中心。https://hub.docker.com/

为了上这三个组件协同工作，Docker守护进程（或者叫Docker容器）运行在一个主机上，并负责构建、运行和分发Docker容器。此外，客户端是一个Docker二进制文件，它接受来自用户的命令并与引擎来回通信。

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503153337147-1252045384.png)

### 1.2. Docker Image

Docker镜像是一个可以从其中启动Docker容器的只读模板。每个镜像又一系列的层组成。（PS：现在发现，把“Image”翻译成专业术语“镜像”的话这里就感觉跟别扭。原文是“Each image consists of a series of layers”，如果按“Image”本来的意思“图像”去理解就很好理解了，对PhotoShop有点儿了解的人都能理解这句话，“图像由一系列图层组成”，真是太形象了。）

Docker如此轻量级的原因之一就是这些层（图层）。当你修改镜像（例如，将应用程序更新到新版本）时，将构建一个新的层。因此，只添加或更新该层，而不是像使用虚拟机那样替换整个映像或完全重建。现在，您不需要发布整个新图像，只需要更新即可，从而使分发Docker镜像更快、更简单。（PS：越发觉得此处用“图像”更好理解，加个新图层或者在原先的图层上做修改即可）

每个镜像都是从一个基本镜像开始的。你也可以使用自己的镜像作为新镜像的基础。如果你有一个基本的Apache镜像，那么你可以使用它作为所有web应用程序镜像的基础。

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503153621138-1095741301.png)

Docker使用一组称为指令的简单描述性步骤来构建镜像。每条指令在镜像中创建一个新层。

1. 运行一条命令
2. 添加一个文件或目录
3. 创建一个环境变量
4. 当启动一个容器时运行一个进程

这些指令被存储在一个叫“Dockerfile”的文件中。当你请求构建镜像时，Docker读取这个Dockerfile文件，然后执行这些指令，并返回最终的镜像。

（PS：关于镜像，记住下面两句话

- **Each image consists of a series of layers.**
- **Each instruction creates a new layer in our image.** 

）

### 1.3. Docker Container

容器由操作系统、用户添加的文件和元数据组成。正如我们所看到的，每个容器都是由一个镜像构建的。镜像告诉Docker容器持有什么、启动容器时运行什么进程以及各种其他配置数据。镜像是只读的。当Docker从映像运行容器时，它会在镜像之上添加一个读写层，然后你的应用程序就可以在其中运行了。

### 1.4. Docker Engine

Docker Host是在安装Docker的时候创建的。一旦Docker Host被创建了，那么你就可以管理镜像和容器了。例如，你可以下载镜像、启动或停止容器。

### 1.5. Docker Client

Docker Client与Docker Host通信，进而你就可以操作镜像和容器了。

 

## 2. 构建一个镜像

### 2.1. Dockerfile

Docker通过从Dockerfile文件中读取指令来构建镜像。Dockerfile是一个文本文档，它包含用户可以在命令行上调用的所有命令来组装一个镜像。docker image build命令会使用这个文件，并执行其中的所有命令。

build命令还传递一个在创建映像期间使用的上下文。这个上下文可以是本地文件系统上的路径，也可以是Git存储库的URL。

关于Dockerfile中可以使用的命令，详见 https://docs.docker.com/engine/reference/builder/

下面是一些常用的命令：

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503154613654-1011074407.png)

### 2.2. 创建你的第一个镜像

首先，创建一个目录hellodocker，然后在此目录下创建一个名为Dockerfile的文本文件，编辑该文件，内容如下：

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503160234632-2039078315.png)

从以上两行命令我们可以看到，该镜像是以ubuntu作为基础基础，CMD命令定义了需要运行的命令。它提供了一个不同的入口/bin/echo，并给出了一个参数“hello world”。

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503160704963-1133921278.png)

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503160936465-1210567097.png)

### 2.3. 用Java创建你的第一个镜像

补充：[OpenJDK](https://hub.docker.com/_/openjdk)是Java平台标准版的一个开源实现，是Docker官方提供的镜像

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503180750979-111646647.png)

首先，让我们创建一个java工程，然后打个jar包，接着创建并编辑Dockerfile

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503180858924-1714900868.png)

使用docker image build构建镜像

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503180948150-1192985833.png)

使用docker container run启动容器

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503181039168-1093902782.png)

其实，跟我们平常那一套没多大区别，不过是把打好的jar包做成镜像而已

### 2.4. 使用Docker Maven Plugin构建镜像

利用Docker Maven Plugin插件我们可以使用Maven来管理Docker镜像和容器。下面是一些预定义的目标：

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503182231766-1896908654.png)

详见 https://github.com/fabric8io/docker-maven-plugin

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503183943983-923824249.png)

补充：Maven中的生命周期、阶段、目标

1. 生命周期有三套：clean、default、site
2. 生命周期由多个阶段组成的，比如default生命周期的阶段包括：clean、validate、compile、
3. 每个阶段由多个目标组成，也就是说目标才是定义具体行为的
4. 插件是目标的具体实现

稍微留一下IDEA里面的Maven区域就不难理解了

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503183646874-1546750066.png)

言归正传，利用docker-maven-plugin来构建镜像的方式有很多，比如，可以配置插件或属性文件，还可以结合Dockerfile，都在这里：

https://github.com/fabric8io/docker-maven-plugin/tree/master/samples

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503191655936-631165367.png)

此处，我们演示用属性文件的方式，首先，定义一段profile配置，比如这样：

```
 1 <?xml version="1.0" encoding="UTF-8"?>
 2 <project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
 3          xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
 4     <modelVersion>4.0.0</modelVersion>
 5     <parent>
 6         <groupId>org.springframework.boot</groupId>
 7         <artifactId>spring-boot-starter-parent</artifactId>
 8         <version>2.1.4.RELEASE</version>
 9         <relativePath/> <!-- lookup parent from repository -->
10     </parent>
11     <groupId>com.cjs.example</groupId>
12     <artifactId>hello-demo</artifactId>
13     <version>0.0.1-SNAPSHOT</version>
14     <name>hello-demo</name>
15     <description>Demo project for Spring Boot</description>
16 
17     <properties>
18         <java.version>1.8</java.version>
19     </properties>
20 
21     <dependencies>
22         <dependency>
23             <groupId>org.springframework.boot</groupId>
24             <artifactId>spring-boot-starter-web</artifactId>
25         </dependency>
26 
27         <dependency>
28             <groupId>org.springframework.boot</groupId>
29             <artifactId>spring-boot-starter-test</artifactId>
30             <scope>test</scope>
31         </dependency>
32     </dependencies>
33 
34     <build>
35         <plugins>
36             <plugin>
37                 <groupId>org.springframework.boot</groupId>
38                 <artifactId>spring-boot-maven-plugin</artifactId>
39             </plugin>
40         </plugins>
41     </build>
42 
43     <profiles>
44         <profile>
45             <id>docker</id>
46             <build>
47                 <plugins>
48                     <plugin>
49                         <groupId>io.fabric8</groupId>
50                         <artifactId>docker-maven-plugin</artifactId>
51                         <version>0.30.0</version>
52                         <configuration>
53                             <images>
54                                 <image>
55                                     <name>hellodemo</name>
56                                     <build>
57                                         <from>openjdk:latest</from>
58                                         <assembly>
59                                             <descriptorRef>artifact</descriptorRef>
60                                         </assembly>
61                                         <cmd>java -jar maven/${project.name}-${project.version}.jar</cmd>
62                                     </build>
63                                 </image>
64                             </images>
65                         </configuration>
66                         <executions>
67                             <execution>
68                                 <id>docker:build</id>
69                                 <phase>package</phase>
70                                 <goals>
71                                     <goal>build</goal>
72                                 </goals>
73                             </execution>
74                             <execution>
75                                 <id>docker:start</id>
76                                 <phase>install</phase>
77                                 <goals>
78                                     <goal>run</goal>
79                                     <goal>logs</goal>
80                                 </goals>
81                             </execution>
82                         </executions>
83                     </plugin>
84                 </plugins>
85             </build>
86         </profile>
87     </profiles>
88 </project> 

```

 然后，在构建的时候指定使用docker这个profile即可

```
1 mvn clean package -Pdocker

```

 ![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503192730806-1331752894.png)

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503192751218-1715827765.png) 

### 2.5. Dockerfile命令（番外篇）

**CMD 与 ENTRYPOINT 的区别**

容器默认的入口点是 /bin/sh，这是默认的shell。

当你运行 docker container run -it ubuntu 的时候，启动的是默认shell。

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503193645252-21447747.png)

ENTRYPOINT 允许你覆盖默认的入口点。例如：

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503194201043-310139550.png) 

这里默认的入口点被换成了/bin/cat

**ADD 与 COPY 的区别**

ADD有COPY所有的能力，而且还有一些额外的特性：

1. 允许在镜像中自动提取tar文件
2. 允许从远程URL下载文件 

 

## 3. 运行一个Docker容器

### 3.1. 交互

以交互模式运行WildFly容器，如下：

```
1 docker container run -it jboss/wildfly

```

默认情况下，Docker在前台运行。**-i**允许与STDIN交互，**-t**将TTY附加到进程上。它们可以一起用作 **-it**

按Ctrl+C停止容器

### 3.2. 分离容器

```
1 docker container run -d jboss/wildfly

```

 用-d选项代替-it，这样容器就以分离模式运行

（PS：-it前台运行，-d后台运行）

### 3.3. 用默认端口

如果你想要容器接受输入连接，则需要在调用docker run时提供特殊选项。 

```
1 $ docker container ls
2 CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS               NAMES
3 93712e8e5233        jboss/wildfly       "/opt/jboss/wildfly/…"   4 minutes ago       Up 4 minutes        8080/tcp            serene_margulis
4 02aa2ed22725        ubuntu              "/bin/bash"              2 hours ago         Up 2 hours                              frosty_bhabha 

```

重启容器

```
1 docker container stop `docker container ps | grep wildfly | awk '{print $1}'`
2 docker container run -d -P --name wildfly jboss/wildfly

```

-P选项将镜像中的任何公开端口映射到Docker主机上的随机端口。--name选项给这个容器起个名字。

```
1 $ docker container ls
2 CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                     NAMES
3 3f2babcc1df7        jboss/wildfly       "/opt/jboss/wildfly/…"   47 seconds ago      Up 47 seconds       0.0.0.0:32768->8080/tcp   wildfly

```

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190503212428845-1497021709.png)

### 3.4. 用指定端口

```
1 docker container stop wildfly
2 docker container rm wildfly 

```

或者你还可以用 docker container rm -f wildfly 来停止并删除容器

```
1 docker container run -d -p 8080:8080 --name wildfly jboss/wildfly

```

格式是： -p hostPort:containerPort 

此选项将主机上的端口映射到容器中的端口。这样就使得我们可以通过主机上的特定的端口来访问容器。

现在我们访问http://localhost:8080/跟刚才http://localhost:32768/是一样的 

### 3.5. 停止容器

```
1 # 按id或name停止指定的容器
2 docker container stop <CONTAINER ID>
3 docker container stop <NAME>
4 
5 # 停止所有容器
6 docker container stop $(docker container ps -q)
7 
8 # 停止已经退出的容器
9 docker container ps -a -f "exited=-1"

```

### 3.6. 删除容器

```
1 # 按id或name删除指定的容器
2 docker container rm <CONTAINER ID>
3 docker container rm <NAME>
4 
5 # 用正则表达式删除匹配到的容器
6 docker container ps -a | grep wildfly | awk '{print $1}' | xargs docker container rm
7 
8 # 删除所有容器
9 docker container rm $(docker container ps -aq)

```

### 3.7. 查看端口映射

```
1 docker container port <CONTAINER ID> or <NAME>

```

## 4. 参考

https://github.com/docker/labs/tree/master/developer-tools/java/ 

https://github.com/fabric8io/docker-maven-plugin 

 

# [Docker Compose 多容器应用](https://www.cnblogs.com/cjsblog/p/10879875.html)

Docker Compose是一个用来定义并运行复杂应用程序的工具。用Compose，你可以在一个文件中定义多个容器应用程序，然后只需一条命令就可以完成使其运行所需的所有操作。

一个使用Docker容器的应用程序通常是由多个容器组成的。使用Docker Compose，不需要编写shell脚本来启动容器。所有的容器都以服务的形式被定义在一个配置文件中，然后使用docker-compose脚本来启动、停止和重启应用和应用中的所有服务，以及服务中的所有容器。

完整的命令列表：

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190517100402471-2065546088.png)

下面是一个Java EE应用连接MySQL的例子

## 配置文件

首先，创建一个目录javaee

然后，在该目录下创建一个文件docker-compose.yml

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190517100915522-1494899092.png)

在这个Compose文件中：

1. 定义了两个服务，分别是“db”和“web”
2. image 指定了服务所使用的镜像
3. environment 定义了用于初始化MySQL的环境变量。其中，MYSQL_DATABASE指定在镜像启动以后创建的数据库的名字；MYSQL_USER 和MYSQL_PASSWORD 用于创建用户并设置密码。该用户将被授予超级管理员的权限类连接到通过MYSQL_DATABASE变量指定的数据库；MYSQL_ROOT_PASSWORD 强制的，用于设置MySQL root账号的密码。
4. Java EE应用程序使用在connection-url中指定的db服务
5. arungupta/docker-javaee:dockerconeu17镜像启动 WildFly Swarm 应用服务器
6. ports 指定端口转发
7. depends_on 指定服务直接的依赖关系。在这个例子中，MySQL会先于WildFly启动

## 启动应用程序

通过执行下面的命令，应用程序中的所有服务都会以独立模式启动

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190517101648340-769811737.png)

或者，你也可以用-f选项来指定配置文件。（PS：默认的配置文件的名字是docker-compose.yml）

接下来，运行命令启动一下

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190517101846329-2109882906.png)

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190517101902546-1906757750.png)

通过浏览器访问

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190517102311419-916540264.png)

最后，停止应用

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190517102345746-125203839.png)

## 备忘单

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190517102409335-1070265784.png)

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190517102417086-262983811.png)

 

# [Docker Compose file](https://www.cnblogs.com/cjsblog/p/10888778.html)

## 1. Service configuration

Compose file 是一个**YAML**文件，用于定义 **services**， **networks**， 和**volumes**。其默认路径是./docker-compose.yml

一个service定义包含了这个服务启动的所有容器的配置，这个操作看起来很像是传递命令行参数给docker container create命令。同样，network和volume定义类似于docker network create 和 docker volume create命令。

与 docker container create 一样，在Dockerfile中指定的选项（比如：CMD、 EXPOSE、 VOLUME、 ENV等）也是一样的，你不需要在docker-compose.yml中再次指定它们。

### 1.1. build

应用于构建时的配置选项

build指定了构建上下文路径

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519123833483-920527974.png)

或者，也可以用一个包含context和可选的dockerfile及args的对象类指定

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519124031411-1473478363.png)

如果在指定build的同时还指定了image，那么将会用指定的镜像来构建

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519124310819-412583813.png)

### 1.2. context

指向包含Dockerfile目录的路径，或者指向git仓库的url

如果这个值是相对路径，那么它相对的是compose file所在的位置（PS：其实就是当前目录）

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519125942961-1839411584.png)

### 1.3. Dockerfile

你也可以用Dockerfile来构建，不过这个时候必须指定context

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519130346450-1039114495.png)

（PS：dockerfile是用来生成镜像的，也就是说构建的时候可以从image构建，也可以从dockerfile构建，是一样的）

### 1.4. args

添加构建参数，这些环境变量只能在构建过程中访问

首先，在Dockerfile中定义变量

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519130646912-1643773476.png)

然后，在构建的时候给这些变量赋值

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519130751348-682229449.png)

或者，下面这种写法也是可以的

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519130824206-1126223484.png)

注意：如果在Dockerfile中，ARG在FROM指令之前，那么在FROM指令下ARG不可用

你也可以在构建参数中省略它们的值，这种情况下会从Compose运行的环境中取值（PS：其实就是环境变量）

### 1.5. cache_from

缓存的镜像列表

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519131428814-2023634058.png)

### 1.6. shm_size

为这个构建的容器设置/dev/shm分区的大小

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519131709465-198285326.png)

### 1.7. configs

授权某个服务可以访问它下面配置的configs，支持两种语法

#### 1.7.1. 短语法

短语法只指定config名称，授权容器可以访问config，并将其挂载到该容器下的/<config_name>

下面的例子授权redis服务访问my_config和my_other_config配置。my_config的值设置的是./my_config.txt，而my_other_config的值指定的是外部资源，这就意味着该值已经被定义在Docker中了。

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519133523206-149509172.png)

#### 1.7.2. 长语法

长语法提供了更细粒度的控制

- source ：config的名称
- target ：被挂载到容器后的文件名称，默认是/<source>
- uid和gid ：被挂载到容器的文件的所有者和所属组ID
- mode ：被挂载到容器中的文件的权限（PS：如果你不熟悉UNIX的权限模式，可以用这个工具 [http://permissions-calculator.org](http://permissions-calculator.org/)）

下面这个例子将在容器下设置my_config和redis_config，设置权限是0440，所有者和所属组都是103，redis服务不可以访问my_other_config配置

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519134624096-1440755568.png)

### 1.8. container_name

自定义容器名称，而不是用默认生成的名称

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519134829244-556768628.png)

### 1.9. depends_on

表示服务之间的依赖关系，服务依赖关系导致以下行为：

- docker-compose up 按照依赖顺序启动服务
- docker-compose up SERVICE 自动包含服务的依赖
- docker-compose stop 按照依赖顺序停止服务

下面的例子中，db和redis会先于web启动，启动web的时候也会创建并启动db和redis，web停止之前会先停止db和redis

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519135632672-1820787711.png)

注意：depends_on不会等待db和redis启动好了再启动web

### 1.10. deploy

只有在集群方式部署的时候这个配置才有效

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519140058700-889746653.png)

#### 1.10.1. mode

global（每个集群节点只有一个容器） 或者 replicated （指定数量的容器）。默认是 replicated

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519140414555-1543863792.png)

### 1.11. env_file

添加一个环境变量文件，可以是单个值或者一个列表

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519140811054-1360920644.png)

如果同一个变量出现在多个文件中，则后者覆盖前者

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519141000817-1585328841.png)

### 1.12. environment

添加一个环境变量，可以覆盖env_file中同名的变量值

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519141158197-1629816447.png)

### 1.13. expose

在不将端口发布到主机的情况下公开端口

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519141425729-1284207449.png)

### 1.14. image

指定容器从哪个镜像启动，可以是镜像ID，也可以是镜像tag

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519141631652-1754290755.png)

### 1.15. network_mode

网络模式

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519141841960-637682156.png)

### 1.16. ports

端口，两种语法

短语法

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519142022171-254821003.png)

长语法

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519142034837-2033148674.png)

### 1.17. restart

重启策略，默认是no

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519142125606-870543320.png)

### 1.18. ulimits

覆盖容器默认的ulimits

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519142240635-979692515.png)

### 1.19. volumes

挂载主机的路径或volumes名称

你可以为单个服务挂载一个主机路径，这个时候就没有定义顶级的volumes了。但是，如果你希望多个服务复用一个volumes，那么这个时候就要定义在顶级了。

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519143705063-87166104.png)

#### 短语法

指定主机上的路径（HOST:CONTAINER），或者一个访问模式（HOST:CONTAINER:ro）

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519144031203-100229911.png)

（PS：稍微解释一下，比如/opt/data:/var/lib/mysql表示挂载到主机的路径是/opt/data，挂载到容器的路径是/var/lib/mysql，其实挂载可以理解为映射）

#### 长语法

- type ：挂载类型（volume， bind，tmpfs）
- source ：挂载的源
- target ：volume被挂载到容器中的路径
- read_only ：设置只读
- propagation ：bind的额外选项
- nocopy ：volume的额外选项，表示当volume创建的时候是否禁止从容器上复制数据
- size ：tmpfs的额外选项，表示挂载的字节大小

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519144956543-1732458317.png)

### 1.20. 指定时长与字节值

时长支持的单位：us，ms，s，m，h

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519145358691-70673516.png)

字节大小支持的单位：b，k，m，g 或者 b，kb，mb，gb

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519145507404-672177438.png)

 

## 2. Volume configuration

下面的例子展示了两个服务，一个数据库的数据目录以一个volumn的形式与另一个服务共享，以至于它可以周期性的备份数据： 

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519150044141-860600692.png)

顶级volumns可以是空的，此时它使用Docker引擎默认提供的驱动（大多数情况下是local）来配置。你也可以指定下列key

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519150414610-1620634569.png)

 

## 3. 示例

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519154622490-1842049669.png) 

## 4. 文档

https://docs.docker.com/compose/compose-file/

https://docs.docker.com/compose/reference/

[http://permissions-calculator.org](http://permissions-calculator.org/)

[https://yaml.org](https://yaml.org/)



# [Docker Swarm mode](https://www.cnblogs.com/cjsblog/p/10890534.html)

## 1. 集群模式基本概念

swarm mode（译：集群模式）

standalone mode（译：单机模式）

以集群模式运行Docker

### 1.1. 集群

Docker引擎内部已经集成了集群管理

一个集群由多个Docker主机组成，它们以集群模式运行。集群中有两种角色：manager和worker。一个给定的主机，它有可能是manager，或者worker，也有可能同时兼具这两种角色。当你创建一个服务的时候，你会定义它们的状态（比如：副本数量、网络和存储资源、对外暴露的端口等等）。Docker负责维护这些状态。如果一个worker节点不可用了，那么Docker会将该节点上的任务转给其它节点。任务是一个运行的容器，它是集群服务的一部分，由manager管理，而非作为一个独立的容器。

相对于单机模式而言，集群模式最关键的优势在于你可以修改服务的配置（比如：networks或volumes等）而不需要手动重启服务。Docker将自动更新配置，停止已经过期的配置的服务任务，并创建与之匹配的新的服务任务。

当Docker以集群模式运行时，你仍然可以在集群的任意一台主机上以单机模式运行，只要它还是集群服务。单机容器与集群服务最主要的区别在于只有集群的manager才可以管理集群，而单机的容器可以被任意守护进程启动。Docker守护进程可以以manager身份、worker身份、或二者兼具的身份参与到集群中。

（小结：

1. 回忆一下，运行中的容器对外提供服务，也就是说服务的载体是容器
2. 单机模式是一台主机上运行多个容器，每个容器单独提供服务；集群模式是多台机器组成一个集群，多个容器一起提供同一个服务；
3. 集群模式的好处是当你修改了服务的配置后无需手动重启服务
4. 集群与单机最大的区别在于，只有集群中的manager才能管理集群中的一切（包括服务、容器都归它管，你无法再一个woker节点上操作容器）

）

### 1.2. 节点

节点是集群中的一个Docker实例，你可以认为它是一个Docker节点。你可以在单台物理机或者云服务上创建一个或多个节点。但是，在生产环境通常是一台物理机或云服务器时一个节点。

为了将你的应用部署到集群中，你需要提交一个服务定义给集群manger节点。manager节点分发任务（task）给worker节点。

manager节点还负责维护集群状态。manager节点选择一个leader来编排任务。

worker节点从manager节点那里接收任务并执行。默认情况下，manager节点上也运行着和worker节点上一样的服务。但是你也可以将它们配置为仅运行manager任务。每个worker节点上都运行着一个agent，它们负责报告分配给该worker节点的任务的相关情况。worker节点向manager节点报告分配给它的任务的当前状态，以便于manager可以更好地分配任务。

### 1.3. 服务与任务

服务是要在manager节点或worker节点上执行的任务的定义。当你创建服务的时候，会指定运行哪个镜像，以及在容器运行的时候执行哪些命令。

任务就是某个容器，以及要在容器中执行的命令

### 1.4. 负载均衡

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519194638269-78479831.png)

## 2. 集群创建

**创建集群**

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519190042762-1840359360.png)

**加入集群**

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519190110474-102195312.png)

**部署服务**

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519190219947-1908571329.png)

**检查服务**

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519190628395-1599826448.png)

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519191406529-1902660245.png)

**动态扩容**

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519191824935-1820222492.png)

**删除服务**

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519192056937-554731237.png)

**动态滚动更新服务**

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519194301486-1507380526.png)

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519194319808-1968093341.png)

**节点下线**

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519195014175-434733065.png)

## 3. 备忘单

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190519195649634-1952772082.png)

## 4. 文档

https://docs.docker.com/engine/swarm/swarm-tutorial/scale-service/

https://docs.docker.com/engine/swarm/swarm-tutorial/rolling-update/

https://docs.docker.com/engine/swarm/ingress/

https://docs.docker.com/engine/reference/commandline/swarm_update/


# [Docker管理应用数据](https://www.cnblogs.com/cjsblog/p/10900291.html)

## 1. Manage data in Docker

默认情况下，所有在容器内部创建的文件被存储在一个可写的容器层。这就意味着：

- 当容器不存在的时候，数据不能被持久化，而且在容器外部想要读取这些数据十分困难。
- 容器的可写的层与运行容器的主机密切相关。你不能轻易地移动数据。
- 要想把数据写到容器的可写层，需要一个存储驱动来管理文件系统。存储驱动提供一个文件系统供Linux内核调用。

Docker有两种方式将容器中的文件存储到主机上，这样的话即使容器停止了，文件依然被持久化下来。这两种方式分别是：volumes和bind mounts。如果你是在Linux上运行Docker，那么你还可以使用tmpfs mount。

## 2. 选择正确的挂载类型

无论你选择哪种挂载类型，数据看起来是一样的。它以目录或者容器的文件系统中的单个文件的形式暴露出来。

下面这幅图可以帮助我们更好的理解 volumes 、 bind mounts 、 tmpfs mounts 三者的区别

![img](https://img2018.cnblogs.com/blog/874963/201905/874963-20190521153829253-1868604409.png)

- **Volumes** 存储在由Docker管理的主机文件系统的一部分中（在Linux中是 /var/lib/docker/volumes/ ）。非Docker进程不应该去修改这部分文件系统。Volumes是在Docker上持久化数据最好的方式。
- **Bind mounts** 数据可以被储存在主机的任何地方。它们甚至可能是重要的系统文件或目录。Docker主机或Docker容器上的非Docker进程可以随时修改它们。
- **tmpfs mounts** 数据只会被存储到主机的内存中，而且从来不会写到文件系统上。

## 3. 关于挂载类型

**Volumes**

Volumes由Docker创建并管理。你可以用docker volume create命令显式地创建一个volume，或者在容器或服务创建的时候创建一个volume。

当你创建了一个volume以后，它被存储到Docker主机上的一个目录下。当你挂载这个volume到一个容器的时候，这个目录就是挂载到容器中的目录。这种方式跟bind mounts很像，除了volumes被Docker管理并与主机的核心功能隔离以外。

一个volume可以同时挂载到多个容器中。当没有一个运行中的容器使用这个volume的时候，这个volume仍然是可用的，并且不会被自动删除。你可以用docker volume prune命令删除未使用的volumes。

当你挂载一个volume的时候，它可能是被命名的或者匿名的。匿名的volumes在它首次被挂载到一个容器中的时候不会被指定一个明确的名字，因此Docker给它们一个随机的名字，以保证它在Docker主机中是唯一的。关于名字，命名的和匿名的volumes在使用上是一样的。

Volumes也支持volume驱动，可以运行你存储数据到远程主机或云上。

**Bind mounts**

与volumes相比，bind mounts有一些功能限制。当你使用bind mount的时候，主机上的一个文件或目录被挂载到一个容器。这个文件或目录关联主机上的绝对路径。这个文件或目录不需要事先在Docker主机上存在，如果没有则会自动在后台创建。Bind mounts的性能非常好，但它依赖于主机的文件系统上有一个特定的目录结构可用。如果你正在开发一个新的Docker应用，建议用volumes。你不能直接用Docker命令来直接管理bind mounts。

**tmpfs mounts**

一个tmpfs挂载不会持久化数据到磁盘，无论是在Docker主机上还是在容器中。容器可以在容器的生命周期中使用它来存储非持久性状态或敏感信息。例如，在内部，群集服务使用tmpfs挂载来将秘钥挂载到服务的容器中。

## 4. volumes最佳实践

**Volumes是在Docker容器和服务中保存数据的首选方式。**使用volumes的一些场景：

- 在多个运行的容器之间共享数据。如果你没有显式地创建一个volume，那么在它首次被挂载到一个容器中的时候会被自动创建。当容器停止或被删除以后，这个volume仍然存在。多个容器可以挂载同一个volume，可以是读写或只读的。只有当你显式地删除volumes的时候它们才会被删除。
- Docker主机不保证有一个给定的目录或文件结构。Volumes解耦从容器运行时到Docker主机之间的配置。
- 当你想要存储你的容器的数据到一个远程主机或云上，而不是本地
- 当你需要备份、恢复，或者将数据从一个Docker主机移动到另一个Docker主机的时候，volumes是最好的选择。你可以停止正在使用这个volume的容器，然后备份这个volume的目录（例如：/var/lib/docker/volumes/<volume-name>）

## 5. bind mounts最佳实践

**一般而言，你应该尽可能地用volumes。**Bind mounts适用于下列情形：

- 在主机和容器之间共享配置。默认情况下，通过挂载/etc/resolv.conf到每个容器上，Docker提供DNS解析到容器。
- 在Docker主机和容器之间开发环境共享源代码和构建artifacts。例如，你可能挂载一个Maven的target/目录到一个容器，并且每次你在Docker主机上构建Maven工程的时候，这个容器可以获得构建后的artifacts。
- 当保证Docker主机的文件或目录结构与容器所需的bind mounts一致时。

## 6. tmpfs mounts最佳实践

当你不想要数据持久化到主机或容器的时候，tmps mounts是最好的选择。这可能是出于安全原因，或者是为了在应用程序需要编写大量非持久性状态数据时保护容器的性能。

## 7. 文档

https://docs.docker.com/storage/

https://docs.docker.com/storage/volumes/
